from django.shortcuts import render ,redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
# to display message
from django.contrib import messages
# for authentication
from django.contrib.auth import authenticate,login

# Create your views here.
def home(request):
    return render(request,'index.html')


def signup(request):
    if request.method=="POST":
        username=request.POST['username']
        fname=request.POST['fname']
        lname=request.POST['lname']
        email=request.POST['email']
        pass1=request.POST['pass1']
        pass2=request.POST['pass2']

        myuser=User.objects.create_user(username,email,pass1)
        myuser.firstname=fname
        myuser.lastname=lname
        # myuser is varible for creating user 

        # to save user in database
        myuser.save()

        # for giving the display that message that user is saved
        messages.success(request,"your account has been created")
        
        #after creating user he/she willl be redirected to signin page
        return redirect('signin')

    return render(request,'app/signup.html')


def signin(request):
    if(request.method=="POST"):
        users=request.POST['username']
        pass1=request.POST['pass1']

        # for authentication of user
        user=authenticate(username=users,password=pass1)
        # authenticate will return none or wrong user
        # authenticate will return not none for coorect user

        if(user is not None):
               login(request,user)
               return redirect(request,'home')
        
        else:
            messages.error(request,"Not user")
            return redirect('signup')

    return render(request,'app/signin.html')


